#include "forms.h"
#include "DV_forms.h"

/*** callbacks and freeobj handles for form DV_main_window ***/
void file_menu_cb(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void dv_browser_cb(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void delete_cb(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void help_menu_cb(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}



