#ifndef _DV_GUI_EXT_H
#define _DV_GUI_H_EXT

/*=============================================================================*/
/* DV_gui_ext.h --- 'external' API                                             */
/*=============================================================================*/

extern int auto_refresh;

void *start_gui(void *arg);
void create_browser_list();

#endif /* _DV_GUI_H_EXT */
