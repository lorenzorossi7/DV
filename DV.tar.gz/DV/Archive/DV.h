#ifndef _DV_H
#define _DV_H 1
//========================================================================================
// DV.h 
//========================================================================================

// #define DV_PORT 5010
// port 5005 is BBHHOST's default
#define DV_PORT 5005

extern int stop_dv_service;
extern int refresh_GUI_now;

#endif // _DV_H
