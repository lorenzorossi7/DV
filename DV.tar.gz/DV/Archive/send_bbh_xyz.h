#ifndef _SEND_BHH_XYZ_H
#define _SEND_BHH_XYZ_H

void send_bbh_xyz(int send_children);

#endif // _SEND_BHH_XYZ_H
