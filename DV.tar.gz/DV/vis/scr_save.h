#ifndef _SCR_SAVE_H
#define _SCR_SAVE_H

void scr_save(const char *file,int jpeg_qf);

#endif /* _SCR_SAVE_H */
