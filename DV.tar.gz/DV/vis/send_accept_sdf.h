#ifndef _SEND_ACCEPT_SDF_H
#define _SEND_ACCEPT_SDF_H

void send_accept_sdf_1g(char *name, double t, grid *g);
void send_accept_sdf(int send_children);

#endif /* _SEND_ACCEPT_SDF_H */
